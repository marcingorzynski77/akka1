﻿namespace PaymentsProcessor.ExternalSystems
{
    class PaymentReceipt
    {
        public int AccountNumber { get; set; }
        public string PaymentConfirmationReceipt { get; set; }
    }
}
