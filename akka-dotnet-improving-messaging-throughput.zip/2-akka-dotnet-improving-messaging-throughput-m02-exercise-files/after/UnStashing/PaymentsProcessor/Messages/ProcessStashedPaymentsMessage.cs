﻿namespace PaymentsProcessor.Messages
{
    class ProcessStashedPaymentsMessage
    {
    }
}
